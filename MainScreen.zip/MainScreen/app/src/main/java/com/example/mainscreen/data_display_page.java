package com.example.mainscreen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import com.github.mikephil.charting.charts.PieChart;

public class data_display_page extends AppCompatActivity {
/*  ConstraintLayout mainLayout = findViewById(R.id.layout_in_scrollview);*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display_page);


    }
}
