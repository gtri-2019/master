package com.example.mainscreen;

//A search menu that will display food items in list form

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Map;

public class search_and_list_page extends AppCompatActivity {
/*
    //class definitions
    String[] tagOptions ={
            "Drink","Entree","Side","Burger","Sandwich","McDonalds","Chick Fil A","Chips","Lay's","Breakfast",
            "Lunch","Dinner","IHOP","Cola", "Coca-Cola", "Coke","Waffle","Snack","Dr Pepper","Chicken",
            "Beef","Potato Chips"};
    private ArrayList<Food> matchingList;
    private ArrayList<String> namesList;
    private ArrayList caloriesList;
    private ArrayList<String> servingSizeList;
    private ListView foodListView;

    private ArrayList<Item> foodList;
    FoodRepository items = new FoodRepository();
    Map<String, Food> foods = items.getFoods();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_page);


        //Creating the instance of ArrayAdapter containing list of language names

        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this,android.R.layout.select_dialog_item,tagOptions);

        //Getting the instance of AutoCompleteTextView
        AutoCompleteTextView actv = findViewById(R.id.foodNameEditTextView);
        actv.setThreshold(1);//will start working from first character
        actv.setAdapter(adapter);//setting the adapter data into the AutoCompleteTextView
    }

    public void searchFoods (View view) {
        ArrayList foodArray = new ArrayList();
        foodArray.add(foods);
        AutoCompleteTextView foodNameText = findViewById(R.id.foodNameEditTextView);

        String searchValue = foodNameText.getText().toString();
    }*/
}
